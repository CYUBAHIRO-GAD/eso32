<?php
require_once '../config.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $username = $_POST['username']??'';
    $password = $_POST['password']??'';
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT * FROM admins WHERE username=?');
    $stmt->execute([$username]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    if($admin && password_verify($password,$admin['password'])){
        session_regenerate_id(true);
        $_SESSION['admin_logged']=true;
        header('Location: dashboard.php'); exit;
    } else { $error='Invalid credentials'; }
}
?>
<!doctype html><html><head><meta charset='utf-8'><title>Admin Login</title><link rel='stylesheet' href='../assets/css/styles.css'></head><body>
<div class='container'>
<h2>Admin Login</h2>
<?php if(!empty($error)) echo '<p style="color:red;">'.htmlspecialchars($error).'</p>'; ?>
<form method='post'><label>Username<input type='text' name='username'></label>
<label>Password<input type='password' name='password'></label>
<button type='submit'>Login</button></form>
</div></body></html>
