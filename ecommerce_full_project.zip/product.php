<?php
require_once 'config.php';
$pdo = getPDO();
$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare('SELECT * FROM products WHERE id=?');
$stmt->execute([$id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);
if(!$product) { echo 'Product not found'; exit; }
?>
<!doctype html><html><head><meta charset='utf-8'><title><?= htmlspecialchars($product['title']) ?></title>
<link rel='stylesheet' href='assets/css/styles.css'></head><body>
<div class='container'>
<h2><?= htmlspecialchars($product['title']) ?></h2>
<p><?= nl2br(htmlspecialchars($product['description'])) ?></p>
<p>Price: $<?= $product['price'] ?></p>
<form method='post' action='cart.php'>
<input type='hidden' name='product_id' value='<?= $product['id'] ?>'>
<label>Quantity <input type='number' name='qty' value='1' min='1'></label>
<button type='submit'>Add to Cart</button>
</form>
</div></body></html>
