# Full E-Commerce Project (MySQL)

- Place all files on PHP-enabled server
- Configure `config.php` with your MySQL credentials
- Run `init_db.php` to create tables and sample product
- Access site via `index.php` and admin via `admin/login.php`
- Default admin: username 'admin', password 'admin123'
