<?php
require_once 'config.php';
$pdo = getPDO();
$products = $pdo->query('SELECT * FROM products LIMIT 6')->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html><html><head><meta charset='utf-8'><title>My Shop</title><link rel='stylesheet' href='assets/css/styles.css'></head><body>
<div class='container'>
<h2>Welcome to My Shop</h2>
<?php foreach($products as $p): ?>
<div>
  <h3><?= htmlspecialchars($p['title']) ?></h3>
  <p>Price: $<?= $p['price'] ?></p>
  <a href="product.php?id=<?= $p['id'] ?>">View</a>
</div>
<hr>
<?php endforeach; ?>
</div></body></html>
