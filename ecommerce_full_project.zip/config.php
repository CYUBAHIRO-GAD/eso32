<?php
session_start();

define('DB_HOST', 'localhost');
define('DB_NAME', 'ecommerce_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('ADMIN_EMAIL', 'admin@example.com');

define('SMTP_ENABLED', true);
define('SMTP_HOST', 'smtp.example.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'smtp-user@example.com');
define('SMTP_PASS', 'smtp-password');
define('SMTP_SECURE', 'tls');

function getPDO(){
    try {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        return $pdo;
    } catch (PDOException $e){
        die('DB Connection failed: ' . $e->getMessage());
    }
}
