<?php
require_once 'config.php';
$pdo = getPDO();
$pdo->exec("CREATE TABLE IF NOT EXISTS products (
id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(255), description TEXT, price DECIMAL(10,2), stock INT DEFAULT 10
) ENGINE=InnoDB;");

$pdo->exec("CREATE TABLE IF NOT EXISTS admins (
id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50), password VARCHAR(255), name VARCHAR(100)
) ENGINE=InnoDB;");

// Insert sample product if table empty
$count = $pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();
if($count==0){
    $stmt = $pdo->prepare('INSERT INTO products (title,description,price) VALUES (?,?,?)');
    $stmt->execute(['Sample Product','This is a sample product.',9.99]);
}

// Insert default admin if table empty
$admin_count = $pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn();
if($admin_count==0){
    $stmt = $pdo->prepare('INSERT INTO admins (username,password,name) VALUES (?,?,?)');
    $stmt->execute(['admin', password_hash('admin123', PASSWORD_DEFAULT),'Administrator']);
}

echo 'Database initialized.';
